import random as Rndm
import pickle as Writer
import re as Reader

Version = "4.0.4.4"

AntiBug = False

SW = {"Name" : 0, "Breed" : 0}
SN = {"Level" : 0, "XP" : 0, "Life" : 0, "Strength" : 0, "Agility" : 0, "Gold" : 0}

Inventory = {"Primary" : "Empty", "Secondary" : "Empty", "Potion" : "Empty"}

StaffItens = ["Venus Staff", "Night Staff", "Infernite Staff", "Gerremy Staff", "Taumalated beta Staff"]
SwordItens = ["Magic Sword", "Nexus Sword", "Dervonium Sword", "Diamond Sword", "Terdromium mega Sword"]
BowedItens = ["Gargoto Bow", "Sworded Bow", "Omegan Crossbow", "Lelbb'one Bow", "Neutroviuned Crossbow"]
HeavyItens = ["Axed Hammer", "Hagurko Axe", "Betanull Hammer", "Morttalor Axe", "Head-Destroyer Hammer"]

DrinkItens = ["Life Potion", "Speed Potion", "Luck Potion", "Shield Potion"]
RHandItens = ["Shield", "Book", "Bandages", "Poison Bottle", "Fired Bottle"]

DataBank = {"Staff" : 3, "Guitar" : 2, "Magic Amulet" : 1, "Venus Staff" : 6, "Night Staff" : 5, "Infernite Staff" : 8, "Gerremy Staff" : 11, "Taumalated beta Staff" : 13,
            "Sword" : 2, "Hatchet" : 4, "-----------" : 0, "Magic Sword" : 3, "Nexus Sword" : 4, "Dervonium Sword" : 9, "Diamond Sword" : 12, "Terdromium mega Sword" : 16,
            "Bow" : 2, "Crossbow" : 4, "------------" : 0, "Gargoto Bow" : 8, "Sworded Bow" : 5, "Omegan Crossbow" : 7, "Lelbb'one Bow" : 10, "Neutroviuned Crossbow" : 24,
            "Hammer" : 6, "Axe" : 5, "Club" : 4, "--" : 0, "Axed Hammer" : 9, "Hagurko Axe" : 6, "Betanull Hammer" : 8, "Morttalor Axe" : 13, "Head-Destroyer Hammer" : 14,

            "Life Potion" : 2, "Speed Potion" : 4, "Luck Potion" : 5, "Shield Potion" : 3,
            "Shield" : 2, "Book" : 1, "Bandages" : 3, "Poison Bottle" : 2, "Fired Bottle" : 5,
            
            "Empty" : 0}

Enemies = ["Goblins", "Little Knights", "Ghosts", "Lizards", "a Archer", "a Troll", "a Dark Witch", "a Orc", "a Hyper Warrior", "a Dragon"]

BossesFHL = ["The Dragon Quin", "a Big Demon", "a Giant Spider", "The fucking Death"]

def YesOrNo(TextO, OpO, TextT, OpT, AN) : #

    #2 Arguments
    if AN == 2 : Input = str(input("\n"+TextO+" "+OpO+"\n"+TextT+" "+OpT+"\n"))

    #1 Arguments
    if AN == 1 : Input = str(input("\n"+TextO+" "+OpO+"\n"))

    if Input == OpO : return True
    if Input == OpT : return False
    if Input != OpO and Input != OpT : YesOrNo(TextO, OpO, TextT, OpT, AN)
#    

def SaveGame() : #

    #Save Game?
    Save = YesOrNo("To save game type", "0", "To continue without save type", "1", 2)

    if Save == True :

        File = open ("Save.txt", "w")
        
        File.write(str(SN["Level"])+"\n"+str(SN["XP"])+"\n"+SW["Name"]+"\n"+SW["Breed"]+"\n"+SW["Class"]+"\n"
                  +str(SN["Life"])+"\n"+str(SN["Strength"])+"\n"+str(SN["Agility"])+"\n"
                  +Inventory["Primary"]+"\n"+Inventory["Secondary"]+"\n"+Inventory["Potion"]+"\n"+str(SN["Gold"])+"\n")
        
        File.close()

        print ("\nOk, let´s come back")
        Adventure()
            
    if Save == False :

        print("\nAll right")
        Adventure()
#

def Adventure() : #

    print ("\nWellcome Back, "+SW["Name"]+"!")
    print ("\nWhat you want do?\n\n Type 1 to see your inventory \n Type 2 to travell \n Type 3 to save game \n Type 4 to exit \n")

    IWant = input("I want : ")

#-----------------------------------------------------------------------------------------------------------#
        
    #Inventory
    if IWant == "1" :

        print("\nYou are in level "+str(SN["Level"])+", with "+str(SN["XP"])+" of XP\n"
              "\n Life : "+str(SN["Life"])+
              "\n Strength : "+str(SN["Strength"])+
              "\n Agility : "+str(SN["Agility"])+"\n"+
              "\n Lft hand : "+Inventory["Primary"]+"("+str(DataBank[Inventory["Primary"]])+")",
              "\n Rgt hand : "+Inventory["Secondary"]+"("+str(DataBank[Inventory["Secondary"]])+")",
              "\n Potion : "+Inventory["Potion"]+"("+str(DataBank[Inventory["Potion"]])+")",
              "\n Gold : "+str(SN["Gold"]))

        CmBk = YesOrNo("To come back type", "0", "", "", 1)
        
        if CmBk == True or CmBk == False: Adventure()

#-----------------------------------------------------------------------------------------------------------#

    #Travel
    if IWant == "2" :
            
        print ("\nWhere are you going?\n\n Type 1 to Dungeons \n Type 2 to Shopping \n Type 3 to Quest \n Type 4 to come back \n")
        GoingTo = input("I'm going to : ")

        if GoingTo == "1" :

            Travel = YesOrNo("Have no save points in dungeons\n\nIf are you sure type", "0", "If you want come back type", "1", 2)

            #Are you sure?
            if Travel == True : Dungeon(1, SN["Life"])
            if Travel == False : Adventure()

        if GoingTo == "2" : Shopping(1, 1)
            
        if GoingTo == "3" :

            IAcpt = YesOrNo("It's can take a fell moments\n\nIf are you sure type", "0", "If you want come back type", "1", 2)
                
            if IAcpt == True : Quest()
            if IAcpt == False : Adventure()
                
        if GoingTo == "4" : Adventure()

#-----------------------------------------------------------------------------------------------------------#

    if IWant == "3" : SaveGame()
    if IWant == "4" : Exit()
#

def Dungeon(Room, Fake) : #

    MaxLife = SN["Life"]
    FakeLife = Fake

    if Room == 1:

        print("\nFist room")
        Luck = Rndm.randrange(1, 20)

        if Luck == 20 :

            print("You found a empty room\nnext")
            Room = 2
        
        if Luck != 20 :

            Enemy = Rndm.choice(Enemies)
            print("You found "+Enemy+"!")

            Battle(MaxLife, FakeLife, Enemy, 1, 1, 1, Room)

#-----------------------------------------------------------------------------------------------------------#

    if Room == 2 : Room = Shopping(2, 2)

#-----------------------------------------------------------------------------------------------------------#                
    if Room == 3 :

        print("\n3st room")
        Luck = Rndm.randrange(1, 20)

        if Luck == 20 :

            print("\nYou found a empty room, again...")
            Room = 4
        
        if Luck != 20 :

            Enemy = Rndm.choice(Enemies)
            print("You found "+Enemy+"!")

            Battle(MaxLife, FakeLife, Enemy, 1, 1, 1, Room)

#-----------------------------------------------------------------------------------------------------------#

    if Room == 4 :

        print("\nYou found a chest!")

        Item = Rndm.choice(RHandItens)
        print("\nAnd inside a "+Item+"!")

        Chest = YesOrNo("To catch the chest item type", "0", "To leave the item type", "1", 2)

        if Chest == True :
            
            Inventory["Secondary"] = Item
            print("Added "+Item+" to inventory")
            Room = 5

        if Chest == False :

            print("\nOk, next room!")
            Room = 5

#-----------------------------------------------------------------------------------------------------------#

    if Room == 5 :

        print("\nLast room")
        Enemy = Rndm.choice(BossesFHL)
        print("You found "+Enemy+"!")
            
        Battle(MaxLife, FakeLife, Enemy, 1, 1, 1, Room)

#-----------------------------------------------------------------------------------------------------------#

    if Room == 6 :

        Says = ["\"We hope see you again!\"", "\"Next time we'll catch you!\"", "Hum... So, do you win?\""]

        MMessage =  Rndm.choice(Says)+" - Monsters "+str(Rndm.randrange(1, 30))+"/"+str(Rndm.randrange(1, 12))+"/"+str(Rndm.randrange(1100, 1500))
        
        print("\nCongratulations! You survived the dungeon!")
        print("-" * len(MMessage))
        print(MMessage)

        Adventure()
#

def Battle(MaxLife, FakeLife, Enemy, EnLife, NumberOf, FirstT, Room) : #

    Fighting = False
    HeroTurn = True
    PotionType = ""
    Bonus = 0
    
    if FirstT == 1 : FightingWth = Bestiary(Enemy) #First Call

    if FirstT == 2 :

        FightingWth = Bestiary(Enemy) #Get Strength and Agility
        FightingWth[0] = NumberOf     #Update Number Of /from last call/
        FightingWth[1] = Life         #Update Life /from last call/

    while Fighting == False : #Start turn

        print("\nWhat you do? \n \n Type 1 to Attack \n Type 2 to Use Potion \n Type 3 to Use Item")
        IDo = input("\nI do : ")

        if IDo == "1" : Fighting = True

        if IDo == "2" :

            Potion = Inventory["Potion"]
            Bonus = DataBank[Potion]
            
            if Potion.startswith("Life") :

                PotionType = "Life"
                print("The "+Potion+" give you "+str(Bonus)+" life points")

            if Potion.startswith("Speed") :

                PotionType = "Speed"
                print("The "+Potion+" turn you "+str(Bonus)+" poits more faster")

            if Potion.startswith("Shield") :

                PotionType = "Shield"
                print("The "+Potion+" made a sheld with "+str(Bonus)+" life points")

            if Potion == "Empty" : print("\nYou have no a potion!")

            Fighting = True
            MyTurn = False

#-----------------------------------------------------------------------------------------------------------#

        if IDo == "3" :

            #Do you have a shield?
            Item = Inventory["Secondary"]

            if Item.endswith("Shield") :

                Bonus = DataBank[Inventory["Secondary"]]
                print("You have a bonus of "+str(Bonus)+" shield points")
                Fighting = True
                HeroTurn = False

            #Do you have a book?
            if Item.endswith("Book") :

                Bonus = DataBank[Inventory["Secondary"]]
                print("You have a bonus of "+str(Bonus)+" knowege points")
                Fighting = True
                HeroTurn = False

            #Do you have a bottle?
            if Item.endswith("Bottle") :

                Bonus = DataBank[Inventory["Secondary"]]
                print("You have a bonus of "+str(Bonus)+" efect points")
                Fighting = True
                HeroTurn = False

            #Do you have a Bandages?
            if Item == "Bandages" :

                SN["Life"] = MaxLife
                print("Your life is full again!")
                Inventory["Secondary"] = "Empty"
                Fighting = True
                HeroTurn = False

#-----------------------------------------------------------------------------------------------------------#

    #Hero attack
    EnemyStatus = 0
                
    if Fighting == True and FakeLife > 0 : #Is fighting and aren't died yet

        if SN["Agility"] > FightingWth[3] or HeroTurn == True or PotionType == "Speed": #If you are faster than or the enemy turn ends or with potion efect

            print("\nYour turn")
            EnemyStatus = HeroAttack(Enemy, FightingWth[1], FightingWth[0]) #Return "Number Of" and "Life"

            FightingWth[0] = EnemyStatus[1] #Life
            FightingWth[1] = EnemyStatus[0] #Number Of
            
            if FightingWth[1] == 0 : InBattle = False

            PotionType = ""
            Bolus = 0
            HeroTurn = False

    #Enemy attack
    if Fighting == True and FightingWth[1] > 0 : #If You don't kill the enemy
        
        if FightingWth[3] > SN["Agility"] or HeroTurn == False :

            print("\nHis turn")
            FightingWth = EnemyAttack(Enemy, FightingWth, FakeLife, Bonus) #Return FightingWth

            FightingWth[0] = EnemyStatus[1]
            FightingWth[1] = EnemyStatus[0]

#-----------------------------------------------------------------------------------------------------------#

    #He is live yet
    if FightingWth[1] > 0 and FakeLife > 0 : Battle(MaxLife, FakeLife, Enemy, EnLife, NumberOf, 2, Room)

    #He died
    if FightingWth[1] <= 0 :

        Room += 1
        Upgrade(FightingWth[2])
        Dungeon(Room, FakeLife)
#    

def HeroAttack(Enemy, EnLife, NumberOf) : #

    Hit = (Rndm.randrange(0, SN["Strength"]) + 1) #Random hit
    hit = Hit + DataBank[Inventory["Primary"]]    #Weapon Bonus 
    print("\nYou attacked "+Enemy+" and he loses "+str(hit)+" life points!")

    #Hits
    if NumberOf > 1 : NumberOf -= 1
    elif NumberOf == 1 : EnLife -= hit

    #Messages
    if NumberOf > 1 : print("\nYou killed one, but have "+str(NumberOf)+" enemmies")

    if NumberOf == 1 :
        
        if EnLife > 0 : print("He is live yet! ("+str(EnLife)+") Life Points")
        elif EnLife <= 0 : print("You killed him")

    List = [EnLife, NumberOf, False]

    return List
#

def EnemyAttack(Enemy, Status, FakeLife, Bonus) : #

    Hit = (Rndm.randrange(0, Status[3]) + 1) #Random hit
    hit = Hit - Bonus #Total hit
    print("\nYou were attacked by "+Enemy+" and lost "+str(hit)+"(-"+str(Bonus)+") life points!")
    FakeLife -= (hit)

    if FakeLife > 0 : print("You are live yet, "+str(FakeLife)+" life points")
    if FakeLife <= 0 :

        print("\nYou died!")
        Exit()
                
    return Status
#

def Shopping(CCB, Room) : #

    Item = ""

    Luck = Rndm.randrange(1, 20)
    Price = Rndm.randrange(1, 100)
    OfficePlace = 1

    if OfficePlace == 1 :
        
        if Room == 1 : print("\nWellcome to shopping")
        if Room == 2 : print("\nShopping room")

        if Luck > Price or Item == Inventory["Primary"] :

            print("\n The shopping are empty today...")
            if Room == 1 : Adventure()
            if Room == 2 : return 3
            if CCB == 2 : OfficePlace = 0
        
        else :

            #What you need?
            if SW["Class"] == "Wizard" : Item = Rndm.choice(StaffItens)
            if SW["Class"] == "Knight" : Item = Rndm.choice(SwordItens)
            if SW["Class"] == "Archer" : Item = Rndm.choice(BowedItens)
            if SW["Class"] == "Brewer" : Item = Rndm.choice(HeavyItens)
        
            SItem = Rndm.choice(RHandItens)
            IItem = Rndm.choice(DrinkItens)
            print("\n Your money : "+str(SN["Gold"])+" G.P. \n")
            print(" Type 1 to buy a "+Item+"("+str(DataBank[Item])+"),"+" for "+str(Price)+" G.P.")
            print(" Type 2 to buy a "+SItem+"("+str(DataBank[SItem])+"),"+" for "+str(Price - Luck) +" G.P.")
            print(" Type 3 to buy a "+IItem+"("+str(DataBank[IItem])+"),"+" for "+str(Price + Luck)+" G.P.\n")
            print(" Type 4 to \"Bye\"")

            ItenBght = input("\nBuy : ")

#-----------------------------------------------------------------------------------------------------------#

            if ItenBght == "1" and SN["Gold"] >= Price :

                print("\nYou bought a "+Item+"!\n")
                Inventory["Primary"] = Item
                SN["Gold"] -= Price
                print("Added "+Inventory["Primary"]+" to inventory")
        
                if Room == 1 and AntiBug == False : Adventure()
                if Room == 2 : return 3
                if CCB == 2 : OfficePlace = 0

            elif AntiBug == False :

                print("You have no money enough")
                if Room == 1 and AntiBug == False : Adventure()
                if Room == 2 : return 3
                if CCB == 2 : OfficePlace = 0

#-----------------------------------------------------------------------------------------------------------#

            if ItenBght == "2" and SN["Gold"] >= (Price - Luck) :

                print("\nYou bought a "+SItem+"!\n")
                Inventory["Secondary"] = SItem
                SN["Gold"] -= (Price - Luck)
                
                print("Added "+Inventory["Secondary"]+" to inventory")
                if Room == 1 and AntiBug == False : Adventure()
                if Room == 2 : return 3
                if CCB == 2 : OfficePlace = 0

            elif AntiBug == False :

                print("You have no money enough")
                if Room == 1 and AntiBug == False : Adventure()
                if Room == 2 : return 3
                if CCB == 2 : OfficePlace = 0

#-----------------------------------------------------------------------------------------------------------#

            if ItenBght == "3" and SN["Gold"] >= (Price + Luck) :

                print("\nYou bought a "+IItem+"!\n")
                Inventory["Potion"] = IItem
                SN["Gold"] -= (Price + Luck)
                print("Added "+Inventory["Potion"]+" to inventory")
            
                if Room == 1 and AntiBug == False : Adventure()
                if Room == 2 : return 3
                if CCB == 2 : OfficePlace = 0

            elif AntiBug == False :

                print("You have no money enough")
                if Room == 1 and AntiBug == False : Adventure()
                if Room == 2 : return 3
                if CCB == 2 : OfficePlace = 0

#-----------------------------------------------------------------------------------------------------------#

            if ItenBght == "4" :

                print("\nPlease come back again")
                if Room == 1 and AntiBug == False : Adventure()
                if Room == 2 : return 3
                if CCB == 2 : OfficePlace = 0
#

def Quest() : #

    #Variables
    if 100 - SN["Gold"] : Time = 100 - SN["Gold"]
        
    Wait = Rndm.randrange(1, Time)
    Percent = 1
    i = 0

    Quests = ["kill a dude", "save my friend", "buy a goat"] 
    Pronoms = ["me", "my wife", "the kingdom", "my village", "my people", "my dark cat"]

    TheQuest = ("\nCan you "+Rndm.choice(Quests)+" for "+Rndm.choice(Pronoms)+"?\n")

    CmBck = ""

#-----------------------------------------------------------------------------------------------------------#
    
    while i < Wait :
    
        i += 0.1
        Percent = (i / Wait) * 100

        print(TheQuest, str(round(Percent))+"% Completed")
            
        if i >= Wait :
            
            print("\nYou got it! And you gained "+str(Wait)+" pieces of Gold")
            SN["Gold"] += Wait
            EndQuest = YesOrNo("To come back type", "0", "", "", 1)

    if EndQuest == True : Adventure()
    if SN["Gold"] == 100 : print("You don´t have quests today!") 
#

def Bestiary(AttackBy) : #

    #Status
    NumberOf = 1
    Life = 1 
    Strength = 1
    Agility = 1

#-----------------------------------------------------------------------------------------------------------#

    #Low Level Enemies
    if AttackBy == "Goblins" or AttackBy == "Little Knights" :

        NumberOf = 3
        Life = 4 * SN["Level"]
        Strength = 3 * SN["Level"]
        Agility = 2 * SN["Level"]

    if AttackBy == "Ghosts" or AttackBy == "Lizards" :

        NumberOf = 2
        Life = 3 * SN["Level"]
        Strength = 2 * SN["Level"]
        Agility = 3 * SN["Level"]

#-----------------------------------------------------------------------------------------------------------#

    #Medium Level Enemies
    if AttackBy == "a Archer" or AttackBy == "a Dark Witch" :

        NumberOf = 1
        Life = 4 * SN["Level"]
        Strength = 2 * SN["Level"]
        Agility = 3 * SN["Level"]

    if AttackBy == "a Troll" or AttackBy == "a Orc" :

        NumberOf = 1
        Life = 5 * SN["Level"]
        Strength = 4 * SN["Level"]
        Agility = 1 * SN["Level"]

#-----------------------------------------------------------------------------------------------------------#

    #Hight Level Enemies
    if AttackBy == "a Hyper Warrior" or AttackBy == "a Dragon" :

        NumberOf = 1
        Life = 6 * SN["Level"]
        Strength = 3 * SN["Level"]
        Agility = 3 * SN["Level"]

#-----------------------------------------------------------------------------------------------------------#

    #Bosses
    if AttackBy == "Dragon Quin" or AttackBy == "a Giant Spider":

        NumberOf = 1
        Life = 12 * SN["Level"]
        Strength = 4 * SN["Level"]
        Agility = 3 * SN["Level"]

    if AttackBy == "The fucking Death" or AttackBy == "Big Demon" :

        NumberOf = 1
        Life = 15 * SN["Level"]
        Strength = 8 * SN["Level"]
        Agility = 2 * SN["Level"]

    List = [NumberOf, Life, Strength, Agility]

    return List
#

def Upgrade(XP) : #

    LevelUp = False

    #XP
    SN["XP"] += XP
    print("You gain "+str(XP)+" exp points!")

    #Level Up
    if SN["Level"] == 1 and SN["XP"] > 100 :
               
        print("\nLevel Up!\n Level 2!")
        SN["Level"] = 2
        LevelUp = True
               
    if SN["Level"] == 2 and SN["XP"] > 200 :

        print("\nLevel Up!\n Level 3!")
        SN["Level"] = 3
        LevelUp = True
               
    if SN["Level"] == 3 and SN["XP"] > 400 :

        print("\nLevel Up!\n Level 4!")
        SN["Level"] = 4
        LevelUp = True
               
    if SN["Level"] == 4 and SN["XP"] > 800 :

        print("\nLevel Up!\n Level 5!")
        SN["Level"] = 5
        LevelUp = True
               
    if SN["Level"] == 5 and SN["XP"] > 1600 :

        print("\nLevel Up!\n You are overpower!")
        SN["Level"] = 6
        LevelUp = True

    Status = ["Life", "Strength", "Agility"]

    if LevelUp == True :

        StatusOn = {"1" : "Life", "2" : "Strength", "3" : "Agility"}

        print("\nYou want turn better :\n\n Type 1 to Life\n Type 2 to Strength\n Type 3 to Agility")
        UpgradeOn = input("\nMake Better on : ")

        MakeBetter = StatusOn[UpgradeOn]
        Points = Rndm.randrange(1, SN["Level"])

        SN[MakeBetter] += Points

        print("\nYou upgraded "+MakeBetter+" on "+str(Points)+"points!")

        LevelUp = False
#

def Start(): #

    #Hello!
    print("Hello Hero! \n")
    Name = input("What is your name : ")
    NameRgt = YesOrNo("\n" +Name+ ", right?\n\nYes :", "0", "Not :", "1", 2)

    #Ok?
    if NameRgt == True :

        SW["Name"] = Name
        Hero()
        
    if NameRgt == False : Start()
#

def Hero(): #

    SN["Life"] = Rndm.randrange(0, 6) + 1
    SN["Strength"] = Rndm.randrange(0, 6) + 1
    SN["Agility"] = Rndm.randrange(0, 6) + 1

    #What are you?
    Options = ("\nOk, "+SW["Name"]+", pick your breed:\n\n Type 1 to Gnome\n Type 2 to Ghost\n Type 3 to Elf\n Type 4 to Lizard\n Type 5 to Troll\n")
    print(Options)

    #Pick
    Breed = input("Breed : ")
    if Breed == "1" :

        SW["Breed"] = "Gnome"
        SN["Agility"] += 3
        if SN["Life"] > 1 : SN["Life"] -= 1
        
    if Breed == "2" :

        SW["Breed"] = "Ghost"
        SN["Life"] += 1
        if SN["Agility"] > 1 : SN["Agility"] -= 1
        
    if Breed == "3" :

        SW["Breed"] = "Elf"
        SN["Life"] += 2
        SN["Agility"] += 1

    if Breed == "4" :

        SW["Breed"] = "Lizard"

        SN["Life"] += 1
        SN["Agility"] += 1
        
    if Breed == "5" :

        SW["Breed"] = "Troll"
        SN["Strength"] += 3
        if SN["Agility"] > 1 : SN["Agility"] -= 1

#-----------------------------------------------------------------------------------------------------------#

    #What your class?
    print("\nNow you are a Hero!\nBut you have to chose a class:")
    Options = ("\n Type 1 to Wizard\n Type 2 to Knight\n Type 3 to Brewer\n Type 4 to Archer\n")
    print (Options)

    #Pick
    Class = input("Class : ")
    if Class == "1" : SW["Class"] = "Wizard"
    if Class == "2" : SW["Class"] = "Knight"
    if Class == "3" : SW["Class"] = "Brewer"
    if Class == "4" : SW["Class"] = "Archer"

    print("\n Name : "+SW["Name"]+"\n Breed : "+SW["Breed"]+"\n Class : "+SW["Class"]+"\n Life : "+str(SN["Life"])+"\n Strength : "+str(SN["Strength"])+"\n Agility : "+str(SN["Agility"])+"\n")

    #Ok?
    Ready = YesOrNo("Ok?\n\nYes :", "0", "Not :", "1", 2)
    if Ready == True : Weapon(SW["Class"])
    if Ready == False : Hero()
#

def Weapon(Class) : #

    #For Wizard
    if Class == "Wizard" :
        
        print("\n\nYou want:\n \n Type 1 to Staff\n Type 2 to Guitar\n Type 3 to Amulet\n")

        weapon = input("Weapon : ")
        
        if weapon == "1" :

            #Staff
            Inventory["Primary"] = "Staff"
            print ("\nAdded "+Inventory["Primary"]+" to inventory")
            
        if weapon == "2" :

            #Guitar
            Inventory["Primary"] = "Guitar"
            print("\nAdded "+Inventory["Primary"]+" to inventory")
            
        if weapon == "3" :

            #Amulet
            Inventory["Primary"] = "Amulet"
            print("\nAdded "+Inventory["Primary"]+" to inventory")

        #Secondary
        Inventory["Secondary"] = "Book"
        print("Added "+Inventory["Secondary"]+" to inventory")

#-----------------------------------------------------------------------------------------------------------#

    #For Knight
    if Class == "Knight" :

        print("You want:\n \n Type 1 to Sword\n Type 2 to Hatchet\n")

        weapon = input("Weapon : ")
        
        if weapon == "1" :

            #Sword
            Inventory["Primary"] = "Sword"
            print ("\nAdded "+Inventory["Primary"]+" to inventory")
            
        if weapon == "2" :

            #Hatchet
            Inventory["Primary"] = "Hatchet"
            print("\nAdded "+Inventory["Primary"]+" to inventory")

        Inventory["Secondary"] = "Shield"
        print("Added "+Inventory["Secondary"]+" to inventory")

#-----------------------------------------------------------------------------------------------------------#

    #For Brewer
    if Class == "Brewer" :

        print("You want:\n \n Type 1 to Hammer\n Type 2 to Axe\n Type 3 to Club\n")

        weapon = input("Weapon : ")
        
        if weapon == "1" :

            #Hammer
            Inventory["Primary"] = "Hammer"
            print("\nAdded "+Inventory["Primary"]+" to inventory")
            
        if weapon == "2" :

            #Axe
            Inventory["Primary"] = "Axe"
            print("\nAdded "+Inventory["Primary"]+" to inventory")
            
        if weapon == "3" :

            #Club
            Inventory["Primary"] = "Club"
            print("\nAdded "+Inventory["Primary"]+" to inventory")

        #Secondary
        Inventory["Potion"] = "Life Potion"
        print("Added "+Inventory["Potion"]+" to inventory")

#-----------------------------------------------------------------------------------------------------------#

    #For Archer
    if Class == "Archer" :

        print ("You want:\n \n Type 1 to Bow\n Type 2 to Crossbow\n")

        weapon = input("Weapon : ")
        
        if weapon == "1" :

            #Bow
            Inventory["Primary"] = "Bow"
            print("\nAdded "+Inventory["Primary"]+" to inventory")
            
        if weapon == "2" :

            #Crossbow
            Inventory["Primary"] = "Crossbow"
            print("\nAdded "+Inventory["Primary"]+" to inventory")
        
        #Secondary
        Inventory["Secondary"] = "Poison Bottle"
        print("Added "+Inventory["Secondary"]+" to inventory\n")

    SN["Level"] = 1
    SN["Gold"] = Rndm.randrange(1, 100)
    SaveGame()
#

def Exit() : #

    AntiBug = True
    print ("Bye!")
    return 0
#

#---Load or New game----------------------------------------------------------------------------------------#

print("Version "+Version)

GameMananger = YesOrNo("To load game type", "0", "To a new game type", "1", 2)

#Save Game
if GameMananger == True :

    File = open("Save.txt", "r")

    #Strings
    Level = str(File.readline())
    XP = str(File.readline())
    
    Name = str(File.readline())
    Breed = str(File.readline())
    Class = str(File.readline())
    
    Life = str(File.readline())
    Strength = str(File.readline())
    Agility = str(File.readline())
    Primary = str(File.readline())
    Secondary = str(File.readline())
    
    Potion = str(File.readline())
    Gold = str(File.readline())

    File.close()

#-----------------------------------------------------------------------------------------------------------#

    #Vaules
    SN["Level"] = int(Level.replace('\n', ''))
    SN["XP"] = int(XP.replace('\n', ''))

    SW["Name"] = Name.replace('\n', '')
    SW["Breed"] = Breed.replace('\n', '')
    SW["Class"] = Class.replace('\n', '')
    
    SN["Life"] = int(Life.replace('\n', ''))
    SN["Strength"] = int(Strength.replace('\n', ''))
    SN["Agility"] = int(Agility.replace('\n', ''))
    
    Inventory["Primary"] = Primary.replace('\n', '')
    Inventory["Secondary"] = Secondary.replace('\n', '')

    Inventory["Potion"] = Potion.replace('\n', '')
    SN["Gold"] = int(Gold.replace('\n', ''))

    Adventure()
    
if GameMananger == False : Start()
